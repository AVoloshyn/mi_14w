Black UI Kit
------------

This ressource is free for personal and commercial use. 
The only restriction: you are not permitted to redistribute it elsewhere without my consent.
The attribution is of course appreciated but not necessary.

Have fun!

Jonathan Moreira - http://www.moreira.ch

